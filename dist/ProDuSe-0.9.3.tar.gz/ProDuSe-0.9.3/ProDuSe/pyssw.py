"""
Adapted from https://github.com/mengyao/Complete-Striped-Smith-Waterman-Library/
And made compatible with python3

License: MIT

Copyright (c) 2012-2015 Boston College

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import ssw_lib
import ctypes as ct

class StrippedSmithWaterman():

    def __init__(self, refSeq, nMatch=2, nMismatch=-2):

        self.dEle2Int = {}
        self.dInt2Ele = {}
        # init DNA score matrix

        self.lEle = ['A', 'C', 'G', 'T', 'N']
        dRc = {'A': 'C', 'C': 'G', 'G': 'C', 'T': 'A', 'a': 'C', 'c': 'G', 'g': 'C', 't': 'A'}
        for i, ele in enumerate(self.lEle):
            self.dEle2Int[ele] = i
            self.dEle2Int[ele.lower()] = i
            self.dInt2Ele[i] = ele
        nEleNum = len(self.lEle)
        lScore = [0 for i in range(nEleNum ** 2)]
        for i in range(nEleNum - 1):
            for j in range(nEleNum - 1):
                if self.lEle[i] == self.lEle[j]:
                    lScore[i * nEleNum + j] = nMatch
                else:
                    lScore[i * nEleNum + j] = nMismatch

        # translate score matrix to ctypes
        mat = (len(lScore) * ct.c_int8)()
        mat[:] = lScore

        self.ssw = ssw_lib.CSsw("/home/crushton/Software/Complete-Striped-Smith-Waterman-Library/src/libssw.so")

        # Load reference sequence
        qNum = self._to_int(refSeq)
        self.qProfile = self.ssw.ssw_init(qNum, ct.c_int32(len(refSeq)), mat, len(self.lEle), 2)

        if len(refSeq) > 30:
            self.nMaskLen = len(refSeq) / 2
        else:
            self.nMaskLen = 15

    def _to_int(self, seq):
        """
        Translate a sequence into numbers
        :param seq: a DNA sequence
        :return:
        """
        num_decl = len(seq) * ct.c_int8
        num = num_decl()
        for i,ele in enumerate(seq):
            try:
                n = self.dEle2Int[ele]
            except KeyError:
                n = self.dEle2Int[self.lEle[-1]]
            finally:
                num[i] = n
        return num

    def align(self, seq):
        """
        Align this sequence against the reference

        :param seq: A string containing a nucleotide sequence
        :return:
        """
        tNum = self._to_int(seq)
        alignment = self._generateAlignment(tNum, len(seq))

    def _generateAlignment(self, tNum, tLen, gapOpenPen=5, gapExtendPen=2, flag=0):
        """
        align one pair of sequences
        @param  qProfile   query profile
        @param  rNum   number array for reference
        @param  nRLen   length of reference sequence
        @param  nFlag   alignment flag
        @param  nMaskLen   mask length
        """

        # Align these sequences
        res = self.ssw.ssw_align(self.qProfile, tNum, ct.c_int32(tLen), gapOpenPen, gapExtendPen, flag, 0, 0, self.nMaskLen)
        nScore = res.contents.nScore
        nScore2 = res.contents.nScore2
        nRefBeg = res.contents.nRefBeg
        nRefEnd = res.contents.nRefEnd
        nQryBeg = res.contents.nQryBeg
        nQryEnd = res.contents.nQryEnd
        nRefEnd2 = res.contents.nRefEnd2
        lCigar = [res.contents.sCigar[idx] for idx in range(res.contents.nCigarLen)]
        nCigarLen = res.contents.nCigarLen
        self.ssw.align_destroy(res)

# For testing
if __name__ == "__main__":
    x = StrippedSmithWaterman("ACACAAAAAATGATATCAGAATGAGAT")
    testAlign = x.align("ACACAAAAAAATGA")