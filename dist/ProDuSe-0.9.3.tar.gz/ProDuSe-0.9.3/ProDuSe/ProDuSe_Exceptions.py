#! /usr/bin/env python

"""
Contains all custom exceptions thrown by ProDuSe

"""

# Thrown if a FASTA or BAM index is missing
class IndexNotFound(Exception):
    pass

