#! /usr/bin/env python

import subprocess
import os
import configargparse

parser = configargparse.ArgumentParser(description="Splits a BAM file into two fastq files")
parser.add_argument("-i", "--input", required=True, type=lambda x: isValidFile(x, parser), help="Input BAM file to be split")
parser.add_argument("-o", "--output", required=True, nargs=2, help="Output forward and reverse fastq files")


def isValidFile(file, parser):
	"""
    Checks to ensure the specified file exists, and throws an error if it does not

    Args:
        file: A filepath
        parser: An argparse.ArgumentParser() object. Used to throw an exception if the file does not exist

    Returns:
        type: The file itself

    Raises:
        parser.error(): An ArgumentParser.error() object, thrown if the file does not exist
    """
	if os.path.isfile(file):
		return file
	else:
		parser.error("The file %s does not exist" % (file))


def main(args=None):

	if args is None:
		args = parser.parse_args()

	# Lets split the BAM file into two fastqs
	samtoolsCom = ["samtools", "fastq", args.input, "-1", args.output[0], "-2", args.output[1]]
	subprocess.check_call(samtoolsCom)


if __name__ == "__main__":
	main()